module.exports = {
  env: {
    browser: true,
    es2021: true,
    node: true,
    jasmine: true,
    "codeceptjs/codeceptjs": true
  },
  extends: [
    'airbnb-base',
    "plugin:codeceptjs/recommended"
  ],
  parserOptions: {
    ecmaVersion: 12,
    sourceType: 'module',
  },
  rules: {
	  'linebreak-style': 0,
    'no-param-reassign': ["error", {"props" : false}],
    'quotes' : ["error", "single", {"allowTemplateLiterals": true}],
    'import/no-extraneous-dependencies': 0,
    'no-console': 0,
    'no-underscore-dangle': 0,
    'no-restricted-globals': 0,
    'consistent-return': 0,
    'no-prototype-builtins': 0,
    'import/prefer-default-export': 0,
    'no-return-assign': 0,
    'class-methods-use-this': 0,
    'no-new': 0
  },
  plugins : ["jasmine", "codeceptjs"]
};
